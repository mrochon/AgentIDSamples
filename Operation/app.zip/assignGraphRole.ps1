

# Get Graph SP object ID
GRAPH_SP_ID=$(az ad sp show \
  --id 00000003-0000-0000-c000-000000000000 \
  --query id -o tsv)

# Assign User.Read.All
az ad sp app-role assignment create \
  --assignee-object-id "53b2c0cc-0779-4d4a-a64a-77af97686264" \
  --assignee-principal-type ServicePrincipal \
  --resource-object-id $GRAPH_SP_ID \
  --app-role-id "9a5d68dd-52b0-4cc2-bd40-abcf44ac3a30"

